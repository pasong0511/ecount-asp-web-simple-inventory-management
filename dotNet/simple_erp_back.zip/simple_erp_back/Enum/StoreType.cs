﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECount.Enum
{
    //저장 모드를 위한 이넘
    public enum StoreType
    {
        InMemoryStore,
        FileStore,
    }
}
