﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECount.Enum
{

    public enum ProductType
    {
        RawMaterial, // 원재료
        Product, // 제품
        Goods, // 상품
    }
}
